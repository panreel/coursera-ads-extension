package roadgraph;

import geography.GeographicPoint;
import geography.RoadSegment;

import java.util.*;
import java.util.stream.Collectors;


class RoadGraph {

	private final Map<GeographicPoint, List<RoadSegment>> adjacencyList = new HashMap<>();


	Set<GeographicPoint> getVertices() {
		return new HashSet<>(adjacencyList.keySet());
	}

	void addPoint(GeographicPoint location) {
		if (adjacencyList.containsKey(location)) {
			return;
		}
		adjacencyList.put(location, new ArrayList<>());
	}

	void addSegment(GeographicPoint from, GeographicPoint to, double length, String roadName, String roadType) {
		List<RoadSegment> segmentsForSource = adjacencyList.get(from);
		segmentsForSource.add(new RoadSegment(from, to, Collections.emptyList(), roadName, roadType, length));
//		segmentsForSource.add(new RoadSegment(to, from, Collections.emptyList(), roadName, roadType, length));
	}

	int countEdges() {
		return adjacencyList.values().stream()
				.mapToInt(List::size).sum();
	}

	boolean containsPoint(GeographicPoint location) {
		return adjacencyList.keySet().contains(location);
	}

	List<GeographicPoint> neighboursOf(GeographicPoint node) {
		if (!adjacencyList.containsKey(node)) {
			return Collections.emptyList();
		}

		return adjacencyList.get(node).stream()
				.map(routeSegment -> routeSegment.getOtherPoint(node))
				.collect(Collectors.toList());
	}
}
