package roadgraph;

import geography.GeographicPoint;

import java.util.*;


class VisitingAlgorithmDFS extends VisitingAlgorithm {

	VisitingAlgorithmDFS(RoadGraph roadGraph) {
		super(roadGraph);
	}

	@Override
	void visitAllNodes(GeographicPoint start, RouteAssemblingVisitor visitor) {

		if (!roadGraph.containsPoint(start)) {
			throw new IllegalStateException("Graph doesn't contain start node!");
		}

		Deque<GeographicPoint> toVisit = new ArrayDeque<>();
		toVisit.add(start);

		while (!toVisit.isEmpty()) {

			GeographicPoint currentNode = toVisit.remove();
			List<GeographicPoint> neighbours = roadGraph.neighboursOf(currentNode);

			visitor.visit(currentNode, neighbours);
			if (visitor.dontCareAboutFurtherNodes()) {
				break;
			}

			neighbours.stream()
					.filter(child -> !visitor.isVisited(child))
					.forEach(toVisit::add);
		}
	}
}
