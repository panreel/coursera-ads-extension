package roadgraph;

import geography.GeographicPoint;

import java.util.*;
import java.util.function.Consumer;
import java.util.logging.Logger;


class RouteAssemblingVisitor {

	private final GeographicPoint start;
	private final GeographicPoint goal;
	private final Consumer<GeographicPoint> visitingCallback;

	private final Set<GeographicPoint> visited = new HashSet<>();
	private final Map<GeographicPoint, GeographicPoint> visitedTo_VisitedFrom = new HashMap<>();
	private static final Logger LOGGER = Logger.getLogger(RouteAssemblingVisitor.class.getName());


	RouteAssemblingVisitor(GeographicPoint start, GeographicPoint goal, Consumer<GeographicPoint> visitingCallback) {
		this.start = start;
		this.goal = goal;
		if (visitingCallback == null) {
			this.visitingCallback = (e -> {});
		} else {
			this.visitingCallback = visitingCallback;
		}
	}

	void visit(GeographicPoint currentNode, List<GeographicPoint> neighbours) {
		visitingCallback.accept(currentNode);
		visited.add(currentNode);
		if (currentNode.equals(goal)) {
			assembleRoute();
		}
		neighbours.stream()
				.filter(this::unvisited)
				.forEach(unvisitedNeighbour -> visitedTo_VisitedFrom.put(unvisitedNeighbour, currentNode));
	}

	boolean dontCareAboutFurtherNodes() {
		return isVisited(goal);
	}

	boolean unvisited(GeographicPoint node) {
		return !isVisited(node);
	}

	boolean isVisited(GeographicPoint node) {
		return visited.contains(node);
	}



	List<GeographicPoint> assembleRoute() {

		if (!isVisited(goal)) {
			return null;
		}

		List<GeographicPoint> reversedRoute = new ArrayList<>();

		GeographicPoint currentNode = goal;
		while (!currentNode.equals(start)) {
			reversedRoute.add(currentNode);
			currentNode = visitedTo_VisitedFrom.get(currentNode);
		}
		reversedRoute.add(start);

		List<GeographicPoint> route;
		Collections.reverse(route = new ArrayList<>(reversedRoute));
		return route;
	}
}
