package roadgraph;

import geography.GeographicPoint;

/**
 * Created by michw_000 on 2016-02-01.
 */
abstract class VisitingAlgorithm {

	final RoadGraph roadGraph;

	VisitingAlgorithm(RoadGraph roadGraph) {
		this.roadGraph = roadGraph;
	}

	abstract void visitAllNodes(GeographicPoint start, RouteAssemblingVisitor routeAssemblingVisitor);
}
