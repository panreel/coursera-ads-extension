package roadgraph;

import geography.GeographicPoint;

import java.util.*;
import java.util.stream.Collectors;


class VisitingAlgorithmBFS extends VisitingAlgorithm {

	VisitingAlgorithmBFS(RoadGraph roadGraph) {
		super(roadGraph);
	}

	@Override
	void visitAllNodes(GeographicPoint start, RouteAssemblingVisitor visitor) {

		if (!roadGraph.containsPoint(start)) {
			throw new IllegalStateException("Graph doesn't contain start node!");
		}

		Deque<GeographicPoint> toVisit = new ArrayDeque<>();
		toVisit.push(start);

		while (!toVisit.isEmpty()) {

			GeographicPoint currentNode = toVisit.pop();
			List<GeographicPoint> neighbours = roadGraph.neighboursOf(currentNode);

			visitor.visit(currentNode, neighbours);
			if (visitor.dontCareAboutFurtherNodes()) {
				break;
			}

			Collections.reverse(neighbours);
			neighbours.stream()
					.filter(visitor::unvisited)
					.collect(Collectors.toList())
					.forEach(toVisit::push);
		}
	}
}
