package roadgraph;

import java.util.HashSet;

import geography.GeographicPoint;

/**
 * @author H.C.T.
 * 
 * Class representing a Vertex in the graph
 *
 */
public class Vertex {

	private GeographicPoint location;
	private int label;
	private HashSet<Edge> edges;
	
	/** Constructs a new Vertex object with the given location and label
	 * @param location geographic point representation of the location represented by this vertex
	 * @param label used to represent/identify this vertex, for graph printing purposes
	 */
	protected Vertex(GeographicPoint location, int label) {
		this.location = location;
		this.label = label;
		edges = new HashSet<Edge>();
	}
	
	/** Overriding equals method so comparison of two "equal" vertices will return the desired result.
	 * Since we assume vertices with the same location are equal and comparing two GeographicPoint
	 * objects, as designed, is most straightforward in this implementation by comparing the string
	 * output, this method does just that to determine if two vertices are equal.  Better approach would
	 * probably be to override the equals method in GeographicPoint object but that's outside the
	 * scope of the assignment and I believe the instructions said not to manipulate other classes
	 */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Vertex)) return false;
		Vertex compareTo = (Vertex) obj;
		return (compareTo.getLocation().toString().equals(this.getLocation().toString()));
	}
	
	/** See comment for equals method for rationale for this override
	 */
	@Override
	public int hashCode() {
		return this.getLocation().hashCode();
	}
	
	/**Fetches the GeographicPoint location of this vertex
	 * @return GeographicPoint location
	 */
	protected GeographicPoint getLocation() {
		return location;
	}

	/**Fetches the label for this vertex
	 * @return int label
	 */
	protected int getLabel() {
		return label;
	}
	
	/** Adds an edge to the list of edges for this vertex
	 * @param neighbor an edge which connects this vertex to another
	 * @return boolean return value for HashSet add method
	 */
	protected boolean addEdge(Edge neighbor) {
		return edges.add(neighbor);
	}

	/**Fetches the HashSet of edges for this vertex.
	 * @return HashSet representing list of edges connected to this vertex
	 */
	protected HashSet<Edge> getEdges() {
		return edges;
	}


}
