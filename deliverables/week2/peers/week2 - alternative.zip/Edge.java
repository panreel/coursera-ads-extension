package roadgraph;

/**
 * @author H.C.T.
 * 
 * Class to represent an edge in the graph
 *
 */
public class Edge {
	private Vertex from;
	private Vertex to;
	private String roadName;
	private String roadType;
	private double length;
	
	/**
	 * 
	 * Generates a new directed Edge with given parameters
	 * 
	 * @param vertex the origin vertex of the edge
	 * @param vertex2 the destination vertex of the edge
	 * @param roadName name of the road represented by the edge
	 * @param roadType type of road represented
	 * @param length length of road
	 */
	protected Edge (Vertex vertex, Vertex vertex2, String roadName,
		String roadType, double length) {
		this.from = vertex;
		this.to = vertex2;
		this.roadName = roadName;
		this.roadType = roadType;
		this.length = length;
	}

	/**Fetches the origin vertex for the edge
	 * @return the origin vertex object
	 */
	protected Vertex getFrom() {
		return from;
	}

	/**Fetches the destination vertex of the edge
	 * @return the destination vertex object
	 */
	protected Vertex getTo() {
		return to;
	}

	/**Fetches the road name represented by the edge
	 * @return String roadName
	 */
	protected String getRoadName() {
		return roadName;
	}

	/**Fetches the road type represented by the edge
	 * @return String roadType
	 */
	protected String getRoadType() {
		return roadType;
	}

	/**Fetches the length of the edge
	 * @return edge (road) length
	 */
	protected double getLength() {
		return length;
	}
}

