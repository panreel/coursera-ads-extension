package roadgraph;

import java.util.ArrayList;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import geography.GeographicPoint;
import geography.RoadSegment;

public class MapNode {
	private GeographicPoint location; // location of the node
	private List<RoadSegment> edges; //list of edges represented as road segments
	
	
	public MapNode(int x, int y){
		location=new GeographicPoint(x,y);
		edges=new ArrayList<RoadSegment>();
	}
	
	public MapNode(GeographicPoint location){
		this.location=location;
		this.edges=new ArrayList<RoadSegment>();
	}
	
	/**retrieves the point reachables via the node's edges
	 * @return : the set of reachable points*/ 
	public Set<GeographicPoint> getReachablePoints(){
		HashSet<GeographicPoint> points =new HashSet<GeographicPoint>();
		for(RoadSegment segment:edges){
			points.add(segment.getOtherPoint(location));
		}
		
		return points;
	}

	public List<RoadSegment> getEdges(){
		return edges;
	}
	
	
	public GeographicPoint getLocation() {
		return location;
	}
	
	/**utility function for debugging*/
	public boolean hasSameLocation(GeographicPoint point){
		if(this.location.x==point.x && this.location.y==point.y){
			return true;
		}
		
		return false;
	}
	
}
